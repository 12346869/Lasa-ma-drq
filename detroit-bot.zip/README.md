# Detroit Bot
Bot Discord cu sistem de moderare și economie.